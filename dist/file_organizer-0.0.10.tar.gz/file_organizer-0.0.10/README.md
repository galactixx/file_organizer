# file_organizer
Super simple and short CLI program to organize files in any directory.
